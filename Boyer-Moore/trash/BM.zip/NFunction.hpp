#ifndef N_FUNCTION_HPP
#define N_FUNCTION_HPP

#include "ZFunction.hpp"

std::vector<int> NFunction(std::vector<uint> str);

#endif

