#include "RFunction.hpp"

std::map<std::string, int> RFunction(std::string &str)
{
    std::map<std::string, int> result;

    for (int i = str.length() - 1; i > 0; --i)
    {
        if (result.find())
    }
}

