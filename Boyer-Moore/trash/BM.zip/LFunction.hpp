#ifndef L_FUNCTION_HPP
#define L_FUNCTION_HPP

#include "NFunction.hpp"

std::vector<int> LFunction(std::vector<int>& nFunction);

#endif

