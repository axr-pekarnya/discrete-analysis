#ifndef LS_FUNCTION_HPP
#define LS_FUNCTION_HPP

#include "NFunction.hpp"

std::vector<int> LsFunction(std::vector<int> &nFunction);

#endif

