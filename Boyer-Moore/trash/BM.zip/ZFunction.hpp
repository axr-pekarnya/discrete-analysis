#ifndef ZFUNCTION_HPP
#define ZFUNCTION_HPP

#include <vector>
#include <string>
#include <algorithm>

std::vector<int> ZFunction(std::vector<uint> &str); 

#endif

