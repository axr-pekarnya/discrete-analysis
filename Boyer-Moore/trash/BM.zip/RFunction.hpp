#ifndef R_FUNCTION_HPP
#define R_FUNCTION_HPP

#include <map>
#include <string>

std::map<uint, int> RFunction(std::string &str);

#endif

